# -- coding: UTF-8 --
# See LICENSE file for full copyright and licensing details.
""" Initializes all the files and directories of Module. """

from . import models
